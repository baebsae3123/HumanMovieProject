import { Button } from './ui/button';
import { Film, Sparkles, Music, Heart } from 'lucide-react';

interface HomePageProps {
  onStart: () => void;
}

export function HomePage({ onStart }: HomePageProps) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full">
        {/* Hero Section */}
        <div className="text-center mb-8 animate-in fade-in duration-700">
          <div className="inline-flex items-center gap-2 bg-white/60 backdrop-blur-sm px-4 py-2 rounded-full mb-6 shadow-sm">
            <Sparkles className="size-4 text-purple-600" />
            <span className="text-sm text-purple-800">AI 영화 취향 분석</span>
          </div>
          
          <h1 className="text-5xl mb-4 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent">
            미루어보자
          </h1>
          
          <p className="text-base text-gray-700 mb-2">
            당신의 영화 취향을 알아보고
          </p>
          <p className="text-base text-gray-700 mb-8">
            완벽한 영화와 음악을 추천받으세요
          </p>

          <Button 
            onClick={onStart}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-6 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 w-full"
          >
            <Film className="mr-2 size-5" />
            취향 테스트 시작하기
          </Button>
        </div>

        {/* Features */}
        <div className="space-y-4 mb-8">
          <div className="bg-white/60 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
            <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-3">
              <Heart className="size-6 text-purple-600" />
            </div>
            <h3 className="text-lg mb-2">감성 취향 분석</h3>
            <p className="text-sm text-gray-600">
              8개의 직관적인 질문으로 당신의 영화 감정 성향을 진단합니다
            </p>
          </div>

          <div className="bg-white/60 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
            <div className="bg-pink-100 w-12 h-12 rounded-full flex items-center justify-center mb-3">
              <Film className="size-6 text-pink-600" />
            </div>
            <h3 className="text-lg mb-2">맞춤 영화 추천</h3>
            <p className="text-sm text-gray-600">
              AI가 당신의 취향에 딱 맞는 영화를 엄선하여 추천합니다
            </p>
          </div>

          <div className="bg-white/60 backdrop-blur-sm p-6 rounded-2xl shadow-lg">
            <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mb-3">
              <Music className="size-6 text-blue-600" />
            </div>
            <h3 className="text-lg mb-2">음악 플레이리스트</h3>
            <p className="text-sm text-gray-600">
              영화 분위기에 맞는 OST와 음악 플레이리스트를 제공합니다
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl mb-1 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              10,000+
            </div>
            <div className="text-xs text-gray-600">테스트 참여자</div>
          </div>
          <div>
            <div className="text-2xl mb-1 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              500+
            </div>
            <div className="text-xs text-gray-600">큐레이션 영화</div>
          </div>
          <div>
            <div className="text-2xl mb-1 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              95%
            </div>
            <div className="text-xs text-gray-600">만족도</div>
          </div>
        </div>
      </div>
    </div>
  );
}
import { motion } from 'motion/react';
import { Sparkles, Film, Music, Brain } from 'lucide-react';

export function LoadingPage() {
  const loadingMessages = [
    { icon: Brain, text: 'AI가 당신의 영화 취향을 분석하고 있어요', delay: 0 },
    { icon: Film, text: '감정 패턴과 선호도를 파악 중입니다', delay: 0.5 },
    { icon: Music, text: '최적의 영화와 음악을 큐레이션하는 중', delay: 1 },
    { icon: Sparkles, text: '곧 당신만의 취향 DNA가 완성됩니다', delay: 1.5 }
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full text-center">
        {/* Main Animation */}
        <motion.div
          className="mb-8"
          animate={{
            scale: [1, 1.1, 1],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div className="w-24 h-24 mx-auto bg-gradient-to-br from-purple-500 via-pink-500 to-blue-500 rounded-full opacity-20 blur-xl"></div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h2 className="text-3xl mb-3 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent">
            분석 중입니다
          </h2>
          <p className="text-sm text-gray-600">잠시만 기다려 주세요...</p>
        </motion.div>

        {/* Loading Messages */}
        <div className="space-y-4">
          {loadingMessages.map((message, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: message.delay, duration: 0.5 }}
              className="bg-white/60 backdrop-blur-sm p-4 rounded-2xl shadow-lg"
            >
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-br from-purple-100 to-pink-100 w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0">
                  <message.icon className="size-5 text-purple-600" />
                </div>
                <p className="text-sm text-gray-700 text-left">{message.text}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Progress Dots */}
        <div className="flex justify-center gap-2 mt-8">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="w-2.5 h-2.5 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full"
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.3, 1, 0.3]
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                delay: i * 0.2
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
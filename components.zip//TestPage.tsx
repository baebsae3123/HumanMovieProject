import { useState } from 'react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { ArrowLeft, ArrowRight } from 'lucide-react';

interface TestPageProps {
  onComplete: (answers: number[]) => void;
}

const questions = [
  {
    id: 1,
    question: '영화를 보고 난 후, 어떤 느낌이 더 좋나요?',
    category: '감정',
    options: [
      { emoji: '😢', text: '깊은 여운과 감동', value: 3 },
      { emoji: '😊', text: '가볍고 즐거운 기분', value: 1 },
      { emoji: '🤔', text: '생각할 거리가 많은 느낌', value: 2 },
      { emoji: '😲', text: '놀라움과 충격', value: 0 }
    ]
  },
  {
    id: 2,
    question: '주말 저녁, 어떤 영화를 보고 싶나요?',
    category: '분위기',
    options: [
      { emoji: '🌙', text: '잔잔하고 조용한 분위기', value: 3 },
      { emoji: '🎨', text: '시각적으로 아름다운 영화', value: 2 },
      { emoji: '⚡', text: '긴장감 넘치는 스릴러', value: 1 },
      { emoji: '💥', text: '화려한 액션 영화', value: 0 }
    ]
  },
  {
    id: 3,
    question: '영화에서 가장 중요하게 생각하는 요소는?',
    category: '선호',
    options: [
      { emoji: '💭', text: '깊이 있는 스토리', value: 3 },
      { emoji: '🎭', text: '배우들의 연기력', value: 2 },
      { emoji: '🎬', text: '감독의 연출력', value: 2 },
      { emoji: '🎵', text: '영상미와 음악', value: 1 }
    ]
  },
  {
    id: 4,
    question: '영화관에서 어떤 장면에 더 몰입하나요?',
    category: '몰입',
    options: [
      { emoji: '💬', text: '인물 간의 대화 장면', value: 3 },
      { emoji: '🌅', text: '아름다운 풍경 장면', value: 2 },
      { emoji: '🏃', text: '추격과 액션 장면', value: 0 },
      { emoji: '🎯', text: '반전과 클라이맥스', value: 1 }
    ]
  },
  {
    id: 5,
    question: '친구에게 영화를 추천한다면?',
    category: '공유',
    options: [
      { emoji: '❤️', text: '인생 영화급으로 감동적인 작품', value: 3 },
      { emoji: '✨', text: '독특하고 예술적인 영화', value: 2 },
      { emoji: '🎉', text: '재미있고 볼만한 영화', value: 1 },
      { emoji: '🔥', text: '화제가 되는 인기 영화', value: 0 }
    ]
  },
  {
    id: 6,
    question: '영화 속 캐릭터 중 누가 가장 매력적인가요?',
    category: '캐릭터',
    options: [
      { emoji: '🌸', text: '복잡한 내면을 가진 주인공', value: 3 },
      { emoji: '🎨', text: '독특하고 개성있는 캐릭터', value: 2 },
      { emoji: '🦸', text: '카리스마 넘치는 영웅', value: 1 },
      { emoji: '🤵', text: '지적이고 전략적인 인물', value: 2 }
    ]
  },
  {
    id: 7,
    question: '영화의 전개 속도는 어떤 것이 좋나요?',
    category: '템포',
    options: [
      { emoji: '🐌', text: '느리지만 깊이있게', value: 3 },
      { emoji: '🚶', text: '적당한 속도로 전개', value: 2 },
      { emoji: '🏃', text: '빠르고 긴장감있게', value: 1 },
      { emoji: '⚡', text: '쉴 틈 없이 빠르게', value: 0 }
    ]
  },
  {
    id: 8,
    question: '영화를 보는 목적은 주로 무엇인가요?',
    category: '목적',
    options: [
      { emoji: '💝', text: '감정적인 위로와 공감', value: 3 },
      { emoji: '🎨', text: '예술적 영감과 감각', value: 2 },
      { emoji: '🧠', text: '지적 자극과 생각거리', value: 2 },
      { emoji: '😄', text: '스트레스 해소와 오락', value: 1 }
    ]
  }
];

export function TestPage({ onComplete }: TestPageProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  const progress = ((currentQuestion + (selectedOption !== null ? 1 : 0)) / questions.length) * 100;

  const handleOptionSelect = (value: number) => {
    setSelectedOption(value);
  };

  const handleNext = () => {
    if (selectedOption !== null) {
      const newAnswers = [...answers, selectedOption];
      setAnswers(newAnswers);
      
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedOption(null);
      } else {
        onComplete(newAnswers);
      }
    }
  };

  const handlePrev = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      const prevAnswer = answers[currentQuestion - 1];
      setAnswers(answers.slice(0, -1));
      setSelectedOption(prevAnswer);
    }
  };

  const question = questions[currentQuestion];

  return (
    <div className="min-h-screen flex flex-col p-4 pt-6">
      <div className="w-full flex-1 flex flex-col">
        {/* Progress Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-600">
              {currentQuestion + 1} / {questions.length}
            </span>
            <span className="text-xs text-gray-600 bg-white/60 backdrop-blur-sm px-3 py-1.5 rounded-full">
              {question.category}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-6 shadow-2xl mb-6 flex-1 flex flex-col justify-center animate-in fade-in duration-500">
          <h2 className="text-xl text-center mb-8 text-gray-800">
            {question.question}
          </h2>

          {/* Options */}
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionSelect(option.value)}
                className={`p-4 rounded-2xl border-2 transition-all duration-300 text-left w-full ${
                  selectedOption === option.value
                    ? 'border-purple-500 bg-purple-50 shadow-lg transform scale-105'
                    : 'border-gray-200 bg-white hover:border-purple-300 hover:shadow-md active:scale-95'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{option.emoji}</span>
                  <span className="text-base text-gray-700">{option.text}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center gap-3">
          <Button
            variant="ghost"
            onClick={handlePrev}
            disabled={currentQuestion === 0}
            className="text-gray-600 flex-1"
          >
            <ArrowLeft className="mr-2 size-4" />
            이전
          </Button>

          <Button
            onClick={handleNext}
            disabled={selectedOption === null}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white flex-1"
          >
            {currentQuestion === questions.length - 1 ? '결과 보기' : '다음'}
            <ArrowRight className="ml-2 size-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
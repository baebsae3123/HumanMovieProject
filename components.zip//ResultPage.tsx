import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Share2, Download, RotateCcw, Music, ExternalLink } from 'lucide-react';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer } from 'recharts';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ResultPageProps {
  result: {
    id: string;
    name: string;
    description: string;
    keywords: string[];
    color: string;
    scores: {
      emotional: number;
      visual: number;
      pace: number;
      action: number;
      depth: number;
    };
    movies: Array<{
      title: string;
      year: number;
      genre: string;
      poster: string;
    }>;
    playlist: string;
  };
  onRetake: () => void;
}

const movieImages = {
  'romance drama': 'https://images.unsplash.com/photo-1735612919187-d03df88f153f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb21hbmNlJTIwZHJhbWElMjBmaWxtfGVufDF8fHx8MTc2MjkzNjAxMnww&ixlib=rb-4.1.0&q=80&w=1080',
  'colorful hotel': 'https://images.unsplash.com/photo-1633595917637-456478c6a28d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGhvdGVsJTIwYXJjaGl0ZWN0dXJlfGVufDF8fHx8MTc2MzAxMjg2OXww&ixlib=rb-4.1.0&q=80&w=1080',
  'cyberpunk future': 'https://images.unsplash.com/photo-1714632475191-388c80290e20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnB1bmslMjBmdXR1cmUlMjBjaXR5fGVufDF8fHx8MTc2MzAxMjg2OXww&ixlib=rb-4.1.0&q=80&w=1080',
  'mystery noir': 'https://images.unsplash.com/photo-1647264157150-491bfd016aa1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXN0ZXJ5JTIwdGhyaWxsZXIlMjBkYXJrfGVufDF8fHx8MTc2Mjk2MDg1OXww&ixlib=rb-4.1.0&q=80&w=1080',
  'desert action': 'https://images.unsplash.com/photo-1735525431749-0b7438aa1c0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBkZXNlcnQlMjByb2FkfGVufDF8fHx8MTc2MzAxMjg3MHww&ixlib=rb-4.1.0&q=80&w=1080',
  'family drama': 'https://images.unsplash.com/photo-1735612919187-d03df88f153f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb21hbmNlJTIwZHJhbWElMjBmaWxtfGVufDF8fHx8MTc2MjkzNjAxMnww&ixlib=rb-4.1.0&q=80&w=1080',
  'musical romance': 'https://images.unsplash.com/photo-1735612919187-d03df88f153f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb21hbmNlJTIwZHJhbWElMjBmaWxtfGVufDF8fHx8MTc2MjkzNjAxMnww&ixlib=rb-4.1.0&q=80&w=1080',
  'social thriller': 'https://images.unsplash.com/photo-1647264157150-491bfd016aa1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxteXN0ZXJ5JTIwdGhyaWxsZXIlMjBkYXJrfGVufDF8fHx8MTc2Mjk2MDg1OXww&ixlib=rb-4.1.0&q=80&w=1080',
  'dream thriller': 'https://images.unsplash.com/photo-1714632475191-388c80290e20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnB1bmslMjBmdXR1cmUlMjBjaXR5fGVufDF8fHx8MTc2MzAxMjg2OXww&ixlib=rb-4.1.0&q=80&w=1080',
  'paris night': 'https://images.unsplash.com/photo-1633595917637-456478c6a28d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGhvdGVsJTIwYXJjaGl0ZWN0dXJlfGVufDF8fHx8MTc2MzAxMjg2OXww&ixlib=rb-4.1.0&q=80&w=1080',
  'spy action': 'https://images.unsplash.com/photo-1735525431749-0b7438aa1c0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBkZXNlcnQlMjByb2FkfGVufDF8fHx8MTc2MzAxMjg3MHww&ixlib=rb-4.1.0&q=80&w=1080',
  'action thriller': 'https://images.unsplash.com/photo-1735525431749-0b7438aa1c0c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBkZXNlcnQlMjByb2FkfGVufDF8fHx8MTc2MzAxMjg3MHww&ixlib=rb-4.1.0&q=80&w=1080'
};

export function ResultPage({ result, onRetake }: ResultPageProps) {
  const chartData = [
    { subject: '감성', value: result.scores.emotional, fullMark: 100 },
    { subject: '비주얼', value: result.scores.visual, fullMark: 100 },
    { subject: '템포', value: result.scores.pace, fullMark: 100 },
    { subject: '액션', value: result.scores.action, fullMark: 100 },
    { subject: '깊이', value: result.scores.depth, fullMark: 100 }
  ];

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: '미루어보자 - 나의 영화 취향은?',
        text: `나의 영화 취향 유형: ${result.name}`,
        url: window.location.href
      });
    } else {
      alert('공유 기능을 지원하지 않는 브라우저입니다.');
    }
  };

  return (
    <div className="min-h-screen py-6 px-4">
      <div className="w-full">
        {/* Header Actions */}
        <div className="flex justify-end gap-2 mb-6">
          <Button variant="outline" size="sm" onClick={handleShare} className="gap-2">
            <Share2 className="size-4" />
            공유
          </Button>
          <Button variant="outline" size="sm" onClick={onRetake} className="gap-2">
            <RotateCcw className="size-4" />
            다시
          </Button>
        </div>

        {/* Result Type Card */}
        <Card className="p-6 mb-6 bg-white/80 backdrop-blur-sm shadow-2xl">
          <div className="text-center mb-6">
            <div className="inline-block mb-4">
              <div 
                className="w-20 h-20 rounded-full mx-auto mb-4 shadow-lg"
                style={{ backgroundColor: result.color }}
              />
            </div>
            
            <Badge className="mb-3 px-4 py-1.5" style={{ backgroundColor: result.color }}>
              나의 영화 취향 유형
            </Badge>
            
            <h1 className="text-3xl mb-4">{result.name}</h1>
            
            <p className="text-base text-gray-700 mb-6">
              {result.description}
            </p>

            <div className="flex flex-wrap justify-center gap-2">
              {result.keywords.map((keyword, index) => (
                <Badge key={index} variant="outline" className="text-sm px-3 py-1">
                  #{keyword}
                </Badge>
              ))}
            </div>
          </div>
        </Card>

        {/* Chart Section */}
        <Card className="p-6 mb-6 bg-white/80 backdrop-blur-sm shadow-xl">
          <h2 className="text-2xl text-center mb-6">감성 스펙트럼 분석</h2>
          
          <div className="h-72 mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={chartData}>
                <PolarGrid stroke="#e5e7eb" />
                <PolarAngleAxis 
                  dataKey="subject" 
                  tick={{ fill: '#6b7280', fontSize: 12 }}
                />
                <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: '#6b7280', fontSize: 10 }} />
                <Radar 
                  name="취향 점수" 
                  dataKey="value" 
                  stroke={result.color}
                  fill={result.color}
                  fillOpacity={0.6}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {chartData.map((item, index) => (
              <div key={index} className="text-center">
                <div className="text-xl mb-1" style={{ color: result.color }}>
                  {item.value}%
                </div>
                <div className="text-xs text-gray-600">{item.subject}</div>
              </div>
            ))}
          </div>
        </Card>

        {/* Movies Section */}
        <Card className="p-6 mb-6 bg-white/80 backdrop-blur-sm shadow-xl">
          <h2 className="text-2xl text-center mb-6">당신을 위한 영화 추천</h2>
          
          <div className="space-y-6">
            {result.movies.map((movie, index) => (
              <div key={index} className="group">
                <div className="relative mb-3 overflow-hidden rounded-xl shadow-lg aspect-[2/3] bg-gray-200">
                  <ImageWithFallback
                    src={movieImages[movie.poster as keyof typeof movieImages]}
                    alt={movie.title}
                    className="w-full h-full object-cover group-active:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent">
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <Button variant="secondary" size="sm" className="w-full gap-2 text-sm">
                        <ExternalLink className="size-3" />
                        자세히 보기
                      </Button>
                    </div>
                  </div>
                </div>
                
                <h3 className="text-lg mb-1">{movie.title}</h3>
                <p className="text-sm text-gray-600 mb-1">{movie.year}</p>
                <Badge variant="outline" className="text-xs">{movie.genre}</Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* Playlist Section */}
        <Card className="p-6 mb-6 bg-white/80 backdrop-blur-sm shadow-xl">
          <div className="flex items-start gap-3 mb-4">
            <div 
              className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: result.color }}
            >
              <Music className="size-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl mb-1">음악 플레이리스트</h2>
              <p className="text-sm text-gray-600">{result.playlist}</p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6 text-center">
            <p className="text-sm text-gray-700 mb-4">
              영화 감상과 함께 즐길 수 있는 맞춤 플레이리스트를 준비했어요
            </p>
            <Button 
              className="gap-2 w-full"
              style={{ backgroundColor: result.color }}
            >
              <Music className="size-4" />
              Spotify에서 듣기
            </Button>
          </div>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <Button
            onClick={onRetake}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white w-full py-6"
          >
            <RotateCcw className="mr-2 size-5" />
            다시 테스트하기
          </Button>
        </div>
      </div>
    </div>
  );
}
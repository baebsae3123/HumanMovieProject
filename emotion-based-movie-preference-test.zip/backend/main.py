# main.py
from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from pymongo import MongoClient
from datetime import datetime
import os
import json

# 모듈 임포트
from models import AnalysisRequest, AnalysisResponse, ResultDBModel
from services.ai_service import analyze_movie_taste

# 환경 변수 로드
load_dotenv()

app = FastAPI(
    title="🎬 미루어보자 API",
    description="AI 기반 영화 취향 분석 백엔드 (FastAPI + Claude + MongoDB)",
    version="1.0.0"
)

# --- MongoDB 연결 설정 ---
MONGODB_URI = os.getenv("MONGODB_URI")
client = None
db = None
analysis_results_collection = None

if MONGODB_URI:
    try:
        client = MongoClient(MONGODB_URI)
        # 데이터베이스 이름: Moive
        DB_NAME = "Moive"
        db = client[DB_NAME]
        
        # 컬렉션 정의: analysis_results
        analysis_results_collection = db['analysis_results'] 
        print(f"✅ MongoDB 연결 성공. 데이터베이스: {DB_NAME}, 컬렉션: analysis_results")
        
    except Exception as e:
        print(f"❌ MongoDB 연결 오류: {e}")
        client = None
else:
    print("⚠️ MONGODB_URI 환경 변수가 설정되지 않았습니다. DB 저장 기능을 건너뜁니다.")


# CORS 설정 (프론트엔드 연동)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 개발 단계에서는 모두 허용. 배포 시 프론트엔드 도메인으로 변경 권장
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- API 엔드포인트 ---

@app.post("/api/analyze", response_model=AnalysisResponse, status_code=status.HTTP_200_OK)
async def analyze_taste(request: AnalysisRequest):
    """
    사용자 답변을 받아 Claude AI 분석을 요청하고 결과를 반환합니다.
    분석 후 MongoDB에 결과를 저장합니다.
    """
    print(f"[{datetime.now().strftime('%H:%M:%S')}] 분석 요청 수신")
    
    if not os.getenv("ANTHROPIC_API_KEY"):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE, 
            detail="AI 서비스 API 키가 설정되지 않았습니다."
        )

    try:
        # 1. AI 서비스 호출
        result = await analyze_movie_taste(request)
        
        # 2. MongoDB에 결과 저장 
        if analysis_results_collection:
            result_to_save = ResultDBModel(
                userId=None, # 현재는 익명 처리
                analysis_data=result,
                created_at=datetime.utcnow()
            )
            # Pydantic 모델을 딕셔너리로 변환하여 MongoDB에 저장
            analysis_results_collection.insert_one(result_to_save.dict(by_alias=True))
            print("✅ 분석 결과 DB 저장 완료.")
        else:
            print("⚠️ MongoDB 컬렉션이 준비되지 않아 DB 저장 기능을 건너뛰었습니다.")

        return result
        
    except Exception as e:
        print(f"🚨 서버 오류 발생: {e}")
        # 오류가 발생해도 클라이언트에게 500 에러와 함께 상세 정보를 반환
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"서버 처리 중 오류가 발생했습니다: {e}")


# 서버 실행 로직은 생략. (이전과 동일)
# ...
// App.tsx 내의 handleTestComplete 함수 수정

const handleTestComplete = async (testAnswers: number[]) => {
  // testAnswers는 숫자 배열 (0~3)일 것으로 가정
  // 백엔드에서 필요한 형식인 { "0": "keyword1", "1": "keyword2", ... } 로 변환 필요
  // (실제 App.tsx 구조에 맞게 변환 로직은 다를 수 있음. 여기서는 예시로 간단히 구성)
  const answersAsKeywords: { [key: string]: string } = {};
  testAnswers.forEach((answer, index) => {
    // 0~3점 숫자를 백엔드가 이해할 수 있는 키워드로 변환하거나,
    // (간단하게) 문자열로 변환하여 질문 번호와 함께 보낸다고 가정
    answersAsKeywords[index.toString()] = answer.toString(); 
  });
  
  setAnswers(testAnswers);
  setCurrentPage('loading');

  try {
    const response = await fetch('http://localhost:8000/api/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ answers: answersAsKeywords }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const resultData = await response.json();
    
    setResult(resultData);
    setCurrentPage('result');

  } catch (error) {
    console.error('분석 요청 실패:', error);
    // 에러 발생 시 에러 페이지 또는 홈으로 리디렉션 처리 필요
    alert('분석 서버 연결에 실패했습니다.');
    setCurrentPage('home');
  }
};
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import LandingPage from './components/LandingPage';
import QuestionPage from './components/QuestionPage';
import LoadingPage from './components/LoadingPage';
import ResultPage from './components/ResultPage';
import MovieDetailPage from './components/MovieDetailPage';

type PageType = 'landing' | 'question' | 'loading' | 'result' | 'movieDetail';

interface MovieData {
  title: string;
  genre: string;
  image: string;
  year: string;
  description: string;
  mood: string[];
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('landing');
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<MovieData | null>(null);

  const handleStart = () => {
    setCurrentPage('question');
  };

  const handleAnswer = (answer: number) => {
    const newAnswers = [...answers, answer];
    setAnswers(newAnswers);

    if (newAnswers.length >= 8) {
      setCurrentPage('loading');
      setTimeout(() => {
        setCurrentPage('result');
      }, 3000);
    }
  };

  const handleRestart = () => {
    setAnswers([]);
    setSelectedMovie(null);
    setCurrentPage('landing');
  };

  const handleMovieClick = (movie: MovieData) => {
    setSelectedMovie(movie);
    setCurrentPage('movieDetail');
  };

  const handleBackToResult = () => {
    setCurrentPage('result');
    setSelectedMovie(null);
  };

  return (
    <div className="min-h-screen bg-[#1d3557]">
      <AnimatePresence mode="wait">
        {currentPage === 'landing' && (
          <motion.div
            key="landing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <LandingPage onStart={handleStart} />
          </motion.div>
        )}

        {currentPage === 'question' && (
          <motion.div
            key="question"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.4 }}
          >
            <QuestionPage 
              currentQuestion={answers.length} 
              onAnswer={handleAnswer}
            />
          </motion.div>
        )}

        {currentPage === 'loading' && (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <LoadingPage />
          </motion.div>
        )}

        {currentPage === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
          >
            <ResultPage 
              answers={answers} 
              onRestart={handleRestart}
              onMovieClick={handleMovieClick}
            />
          </motion.div>
        )}

        {currentPage === 'movieDetail' && selectedMovie && (
          <motion.div
            key="movieDetail"
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <MovieDetailPage 
              movie={selectedMovie}
              onBack={handleBackToResult}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

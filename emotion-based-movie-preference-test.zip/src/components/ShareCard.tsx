import { motion } from 'motion/react';
import { Button } from './ui/button';
import { X, Download, Share2 } from 'lucide-react';

interface ShareCardProps {
  result: {
    name: string;
    color: string;
  };
  onClose: () => void;
}

export default function ShareCard({ result, onClose }: ShareCardProps) {
  return (
    <div className="min-h-screen flex items-center justify-center px-5 py-8">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full"
      >
        {/* Close button */}
        <div className="flex justify-end mb-3">
          <Button
            onClick={onClose}
            variant="ghost"
            className="text-white hover:bg-white/10 active:bg-white/20 rounded-full size-11 p-0 active:scale-95 transition-all"
          >
            <X className="size-5" />
          </Button>
        </div>

        {/* Share Card */}
        <div className="relative">
          {/* Card content */}
          <div
            className={`bg-gradient-to-br ${result.color} rounded-3xl p-10 shadow-2xl overflow-hidden`}
          >
            {/* Background decoration */}
            <div className="absolute top-0 right-0 w-56 h-56 bg-white/10 rounded-full blur-3xl -mr-28 -mt-28" />
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-black/10 rounded-full blur-3xl -ml-20 -mb-20" />

            <div className="relative z-10">
              {/* Header */}
              <div className="text-center mb-10">
                <div className="inline-block bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-5">
                  <span className="text-white text-sm">나의 영화 감성 DNA</span>
                </div>
                <h2 className="text-white mb-3 leading-tight">
                  {result.name}
                </h2>
                <p className="text-white/90 text-sm leading-relaxed">
                  8문항으로 알아본 나의 영화 취향
                </p>
              </div>

              {/* Decorative elements */}
              <div className="flex justify-center gap-2 mb-10">
                {[...Array(5)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 bg-white/40 rounded-full"
                    animate={{
                      scale: [1, 1.3, 1],
                      opacity: [0.4, 1, 0.4],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: i * 0.2,
                    }}
                  />
                ))}
              </div>

              {/* Bottom branding */}
              <div className="text-center">
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl px-6 py-5">
                  <p className="text-white/90 mb-1">미루어보자</p>
                  <p className="text-white/70 text-xs">
                    당신의 영화 취향 테스트
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="mt-5 flex gap-3">
            <Button
              className="flex-1 bg-white/10 hover:bg-white/20 active:bg-white/25 backdrop-blur-sm text-white border border-white/20 hover:border-white/40 py-7 rounded-2xl active:scale-95 transition-all"
            >
              <Download className="size-5 mr-2" />
              <span className="text-sm">이미지로 저장</span>
            </Button>
            <Button
              className="flex-1 bg-white/10 hover:bg-white/20 active:bg-white/25 backdrop-blur-sm text-white border border-white/20 hover:border-white/40 py-7 rounded-2xl active:scale-95 transition-all"
            >
              <Share2 className="size-5 mr-2" />
              <span className="text-sm">공유하기</span>
            </Button>
          </div>

          <p className="text-white/60 text-center text-sm mt-5">
            친구들도 테스트해보세요!
          </p>
        </div>
      </motion.div>
    </div>
  );
}

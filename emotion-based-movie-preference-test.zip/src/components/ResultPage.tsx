import { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Share2, RotateCcw, Play } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from 'recharts';
import ShareCard from './ShareCard';

interface ResultPageProps {
  answers: number[];
  onRestart: () => void;
  onMovieClick: (movie: MovieData) => void;
}

interface MovieData {
  title: string;
  genre: string;
  image: string;
  year: string;
  description: string;
  mood: string[];
  type: number;
}

// 결과 유형 정의
const resultTypes = [
  {
    id: 1,
    name: '따뜻한 감성 몽상가',
    description: '당신은 영화 속에서 따뜻한 감동과 인간적인 이야기를 찾는 감성적인 영화 애호가입니다. 잔잔하지만 깊은 울림을 주는 작품들에 끌리며, 영화를 통해 삶의 의미와 위안을 얻습니다.',
    directors: '켄 로치, 히로카즈 고레에다, 그레타 거윅',
    color: 'from-orange-400 to-pink-400',
  },
  {
    id: 2,
    name: '긴장의 쾌감 추구자',
    description: '당신은 탄탄한 스토리와 반전, 긴장감을 사랑하는 스릴러 마니아입니다. 예측 불가능한 전개와 치밀한 구성에 매력을 느끼며, 영화를 통해 지적인 쾌감을 경험합니다.',
    directors: '크리스토퍼 놀란, 데니스 빌뇌브, 봉준호',
    color: 'from-blue-500 to-purple-600',
  },
  {
    id: 3,
    name: '몽환적 감성 탐색자',
    description: '당신은 독창적인 영상미와 예술적 연출을 중요하게 생각하는 시각적 감성파입니다. 몽환적이고 아름다운 장면들에 빠져들며, 영화를 하나의 예술 작품으로 감상합니다.',
    directors: '웨스 앤더슨, 박찬욱, 테렌스 맬릭',
    color: 'from-purple-400 to-pink-500',
  },
  {
    id: 4,
    name: '철학적 사유 애호가',
    description: '당신은 영화 속 깊은 메시지와 철학적 주제를 탐구하는 것을 즐기는 사색가입니다. 현실을 반영하고 생각거리를 주는 작품들을 선호하며, 영화를 통해 세상을 이해하고자 합니다.',
    directors: '안드레이 타르코프스키, 다르덴 형제, 켈리 라이카트',
    color: 'from-slate-500 to-blue-500',
  },
];

// 영화 추천 목록
const movieRecommendations: MovieData[] = [
  {
    title: '비포 선라이즈',
    genre: '로맨스/드라마',
    image: 'https://images.unsplash.com/photo-1745118037962-3c86d081e592?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3ZpZSUyMHBvc3RlciUyMHJvbWFuY2V8ZW58MXx8fHwxNzYzNjE0MzM2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    year: '2023',
    description: '비포 선라이즈는 사랑과 희생, 그리고 삶의 가치를 탐구하는 영화입니다. 주인공들은 서로를 위해 희생하는 사랑을 표현하며, 삶의 의미를 깊이 생각하게 합니다.',
    mood: ['감성', '사유'],
    type: 1,
  },
  {
    title: '인셉션',
    genre: '스릴러/SF',
    image: 'https://images.unsplash.com/photo-1662937600299-7cb9ff0b1061?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aHJpbGxlciUyMGRhcmslMjBjaW5lbWF8ZW58MXx8fHwxNzYzNTYwNjA5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    year: '2010',
    description: '인셉션은 꿈 속에서의 스파이 활동을 그린 영화입니다. 주인공들은 꿈 속에서 정보를 훔치거나 변경하려고 하며, 현실과 꿈의 경계가 흐려지는 복잡한 이야기를 펼칩니다.',
    mood: ['긴장감', '사유'],
    type: 2,
  },
  {
    title: '그랜드 부다페스트 호텔',
    genre: '코미디/드라마',
    image: 'https://images.unsplash.com/photo-1763192903082-27dcc980ba3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWdpY2FsJTIwZmFudGFzeSUyMHNjZW5lfGVufDF8fHx8MTc2MzYxNDM0MXww&ixlib=rb-4.1.0&q=80&w=1080',
    year: '2014',
    description: '그랜드 부다페스트 호텔은 독특한 스토리와 코미디적인 요소를 결합한 영화입니다. 주인공들은 호텔에서 일어나는 일련의 사건들을 통해 서로를 이해하고, 사랑을 발견하게 됩니다.',
    mood: ['감성', '예술성'],
    type: 3,
  },
  {
    title: '트리 오브 라이프',
    genre: '드라마/예술',
    image: 'https://images.unsplash.com/photo-1630415321665-f4da1a7ecbea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpZSUyMGZpbG0lMjBhZXN0aGV0aWN8ZW58MXx8fHwxNzYzNjE0MzM3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    year: '2018',
    description: '트리 오브 라이프는 삶의 가치와 의미를 탐구하는 영화입니다. 주인공들은 삶의 다양한 측면을 통해 삶의 가치를 깊이 생각하게 됩니다.',
    mood: ['사유', '예술성'],
    type: 4,
  },
];

export default function ResultPage({ answers, onRestart, onMovieClick }: ResultPageProps) {
  const [showShareCard, setShowShareCard] = useState(false);

  // 답변 분석하여 유형 결정
  const calculateResult = () => {
    const counts = [0, 0, 0, 0, 0];
    answers.forEach(answer => {
      counts[answer]++;
    });
    
    const maxCount = Math.max(...counts.slice(1));
    const resultType = counts.indexOf(maxCount);
    
    return resultTypes[resultType - 1] || resultTypes[0];
  };

  const result = calculateResult();

  // 감정 스펙트럼 데이터
  const emotionData = [
    { emotion: '감성', value: answers.filter(a => a === 1).length * 25 },
    { emotion: '긴장감', value: answers.filter(a => a === 2).length * 25 },
    { emotion: '예술성', value: answers.filter(a => a === 3).length * 25 },
    { emotion: '사유', value: answers.filter(a => a === 4).length * 25 },
    { emotion: '몰입도', value: 75 + Math.random() * 25 },
  ];

  // 해당 유형에 맞는 영화 추천
  const recommendedMovies = movieRecommendations.filter(movie => 
    Math.abs(movie.type - (answers.filter(a => a === 1).length > 3 ? 1 : answers.filter(a => a === 2).length > 3 ? 2 : 3)) <= 1
  );

  if (showShareCard) {
    return (
      <ShareCard
        result={result}
        onClose={() => setShowShareCard(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1d3557] via-[#2d4a6f] to-[#1d3557] py-8 px-5 pb-20">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-block mb-3">
            <div className={`bg-gradient-to-r ${result.color} text-white px-5 py-2 rounded-full text-sm`}>
              당신의 영화 감성 DNA
            </div>
          </div>
          <h1 className="text-white mb-4 px-4 leading-tight">
            {result.name}
          </h1>
          <p className="text-white/80 leading-relaxed px-2">
            {result.description}
          </p>
        </motion.div>

        {/* Emotion Spectrum Chart */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-white/5 backdrop-blur-sm rounded-3xl p-6 mb-6 border border-white/10"
        >
          <h3 className="text-white mb-4 text-center">감정 스펙트럼 분석</h3>
          <ResponsiveContainer width="100%" height={280}>
            <RadarChart data={emotionData}>
              <PolarGrid stroke="#ffffff30" />
              <PolarAngleAxis 
                dataKey="emotion" 
                tick={{ fill: '#ffffff80', fontSize: 11 }}
              />
              <PolarRadiusAxis 
                angle={90} 
                domain={[0, 100]}
                tick={{ fill: '#ffffff60', fontSize: 9 }}
              />
              <Radar
                name="감정"
                dataKey="value"
                stroke="#a78bfa"
                fill="#a78bfa"
                fillOpacity={0.6}
              />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Director Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/5 backdrop-blur-sm rounded-3xl p-5 mb-6 border border-white/10"
        >
          <h3 className="text-white mb-2">추천 감독/스타일</h3>
          <p className="text-white/70 text-sm leading-relaxed">{result.directors}</p>
        </motion.div>

        {/* Movie Recommendations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-6"
        >
          <h3 className="text-white mb-4">당신을 위한 추천 영화</h3>
          <div className="grid grid-cols-2 gap-3">
            {recommendedMovies.slice(0, 4).map((movie, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="group cursor-pointer active:scale-95 transition-transform"
                onClick={() => onMovieClick(movie)}
              >
                <div className="relative rounded-2xl overflow-hidden mb-2 shadow-xl">
                  <ImageWithFallback
                    src={movie.image}
                    alt={movie.title}
                    className="w-full aspect-[2/3] object-cover transition-transform group-active:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-active:opacity-100 transition-opacity flex items-end p-3">
                    <Play className="size-7 text-white" />
                  </div>
                </div>
                <h4 className="text-white text-sm mb-0.5 leading-snug">{movie.title}</h4>
                <p className="text-white/50 text-xs">{movie.genre}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="flex gap-3"
        >
          <Button
            onClick={() => setShowShareCard(true)}
            className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 active:from-purple-700 active:to-pink-700 text-white py-7 rounded-2xl shadow-lg active:scale-95 transition-all"
          >
            <Share2 className="size-5 mr-2" />
            공유하기
          </Button>
          <Button
            onClick={onRestart}
            variant="outline"
            className="bg-white/10 hover:bg-white/20 active:bg-white/25 text-white border-white/20 hover:border-white/40 py-7 px-7 rounded-2xl active:scale-95 transition-all"
          >
            <RotateCcw className="size-5" />
          </Button>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="text-white/40 text-center text-xs mt-6"
        >
          이 결과는 AI 기반 감정 분석으로 생성되었습니다
        </motion.p>
      </div>
    </div>
  );
}

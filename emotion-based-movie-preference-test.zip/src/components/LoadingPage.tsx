import { motion } from 'motion/react';

export default function LoadingPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-5 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#1d3557] via-[#2d4a6f] to-[#1d3557]" />

      {/* Animated wave background */}
      <div className="absolute inset-0">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute inset-0"
            style={{
              background: `radial-gradient(circle at 50% 50%, rgba(139, 92, 246, ${0.1 - i * 0.02}) 0%, transparent 70%)`,
            }}
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.3, 0.1, 0.3],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              delay: i * 0.4,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 text-center max-w-md w-full">
        {/* Loading animation */}
        <div className="mb-10">
          <div className="flex items-center justify-center gap-2">
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                className="w-3 h-3 bg-white rounded-full"
                animate={{
                  y: [0, -20, 0],
                  opacity: [0.3, 1, 0.3],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: i * 0.2,
                }}
              />
            ))}
          </div>
        </div>

        {/* Text */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-white mb-4 leading-tight px-4">
            AI가 당신의 감정 패턴을<br />분석하는 중...
          </h2>
          <p className="text-white/60 px-6">
            당신만의 영화 감성 DNA를 찾고 있습니다
          </p>
        </motion.div>

        {/* Wave visualization */}
        <div className="mt-12 flex items-center justify-center gap-1">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="w-1 bg-gradient-to-t from-purple-400 to-pink-400 rounded-full"
              animate={{
                height: [20, 60, 20],
              }}
              transition={{
                duration: 1.2,
                repeat: Infinity,
                delay: i * 0.05,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* Progress percentage */}
        <motion.div
          className="mt-10 text-white/40 text-sm"
          animate={{
            opacity: [0.4, 1, 0.4],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
        >
          감정 분석 진행 중...
        </motion.div>
      </div>
    </div>
  );
}

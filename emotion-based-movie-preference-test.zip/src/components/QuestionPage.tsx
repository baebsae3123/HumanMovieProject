import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface QuestionPageProps {
  currentQuestion: number;
  onAnswer: (answer: number) => void;
}

const questions = [
  {
    id: 1,
    text: '주말 저녁, 당신이 선택할 영화는?',
    image: 'https://images.unsplash.com/photo-1685134392852-686912b64c5c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWF0aWMlMjBtb29keSUyMGdyYWRpZW50fGVufDF8fHx8MTc2MzYxNDIzNXww&ixlib=rb-4.1.0&q=80&w=1080',
    options: [
      { text: '따뜻한 감동이 있는 드라마', value: 1 },
      { text: '긴장감 넘치는 스릴러', value: 2 },
      { text: '상상력을 자극하는 판타지', value: 3 },
      { text: '현실을 반영한 다큐멘터리', value: 4 },
    ],
  },
  {
    id: 2,
    text: '영화를 보며 무엇을 느끼고 싶으신가요?',
    image: 'https://images.unsplash.com/photo-1641466577787-81d128ed8e51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXJtJTIwZW1vdGlvbmFsJTIwbGlnaHR8ZW58MXx8fHwxNzYzNjE0MjM1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    options: [
      { text: '깊은 울림과 감동', value: 1 },
      { text: '짜릿한 쾌감과 긴장감', value: 2 },
      { text: '몽환적이고 신비로운 느낌', value: 3 },
      { text: '날카로운 통찰과 생각거리', value: 4 },
    ],
  },
  {
    id: 3,
    text: '가장 기억에 남는 영화 장면은?',
    image: 'https://images.unsplash.com/photo-1743685889437-210ad44b6c5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3ZpZSUyMGZpbG0lMjBhZXN0aGV0aWN8ZW58MXx8fHwxNzYzNjE0MjM1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    options: [
      { text: '주인공의 성장과 변화', value: 1 },
      { text: '반전이 있는 클라이맥스', value: 2 },
      { text: '아름다운 영상미', value: 3 },
    ],
  },
  {
    id: 4,
    text: '선호하는 영화 분위기는?',
    image: 'https://images.unsplash.com/photo-1657049420642-dfbb780d0abd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkcmFtYXRpYyUyMHN1bnNldCUyMHNreXxlbnwxfHx8fDE3NjM1NDU5MTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    options: [
      { text: '따뜻하고 포근한', value: 1 },
      { text: '어둡고 긴장감 있는', value: 2 },
      { text: '몽환적이고 예술적인', value: 3 },
      { text: '차분하고 담담한', value: 4 },
    ],
  },
  {
    id: 5,
    text: '영화를 선택할 때 중요하게 생각하는 것은?',
    image: 'https://images.unsplash.com/photo-1759547020777-14a1ca4c3fdf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWElMjBwb3N0ZXIlMjB2aW50YWdlfGVufDF8fHx8MTc2MzYxNDIzNnww&ixlib=rb-4.1.0&q=80&w=1080',
    options: [
      { text: '감정적 몰입도', value: 1 },
      { text: '스토리의 탄탄함', value: 2 },
      { text: '독창적인 연출', value: 3 },
    ],
  },
  {
    id: 6,
    text: '영화를 본 후 느끼고 싶은 감정은?',
    image: 'https://images.unsplash.com/photo-1685134392852-686912b64c5c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWF0aWMlMjBtb29keSUyMGdyYWRpZW50fGVufDF8fHx8MTc2MzYxNDIzNXww&ixlib=rb-4.1.0&q=80&w=1080',
    options: [
      { text: '따뜻한 여운', value: 1 },
      { text: '카타르시스', value: 2 },
      { text: '영감과 동경', value: 3 },
      { text: '깊은 사유', value: 4 },
    ],
  },
  {
    id: 7,
    text: '좋아하는 영화 속 색감은?',
    image: 'https://images.unsplash.com/photo-1620983626630-6b8a2ce4b9fe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZW9uJTIwY2l0eSUyMG5pZ2h0fGVufDF8fHx8MTc2MzUyMjkxMHww&ixlib=rb-4.1.0&q=80&w=1080',
    options: [
      { text: '따뜻한 베이지와 오렌지 톤', value: 1 },
      { text: '차갑고 어두운 블루 톤', value: 2 },
      { text: '선명한 컬러와 그라데이션', value: 3 },
    ],
  },
  {
    id: 8,
    text: '당신의 영화 감상 스타일은?',
    image: 'https://images.unsplash.com/photo-1641466577787-81d128ed8e51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXJtJTIwZW1vdGlvbmFsJTIwbGlnaHR8ZW58MXx8fHwxNzYzNjE0MjM1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    options: [
      { text: '감정에 온전히 빠져듦', value: 1 },
      { text: '스토리 전개에 집중', value: 2 },
      { text: '연출과 미장센 감상', value: 3 },
      { text: '메시지와 주제 분석', value: 4 },
    ],
  },
];

export default function QuestionPage({ currentQuestion, onAnswer }: QuestionPageProps) {
  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  if (!question) return null;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Progress bar */}
      <div className="bg-[#1d3557]/95 backdrop-blur-md px-5 pt-12 pb-5 border-b border-white/10">
        <div className="max-w-md mx-auto">
          <div className="flex justify-between items-center mb-3">
            <span className="text-white/70 text-sm">질문 {currentQuestion + 1} / {questions.length}</span>
            <span className="text-white/70 text-sm">{Math.round(progress)}%</span>
          </div>
          <Progress 
            value={progress} 
            className="h-2 bg-white/10"
            indicatorClassName="bg-gradient-to-r from-purple-400 to-pink-400"
          />
        </div>
      </div>

      {/* Question content */}
      <div className="flex-1 flex items-center justify-center px-5 py-6">
        <div className="max-w-md w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* Image */}
            <div className="relative mb-5 rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src={question.image}
                alt="질문 이미지"
                className="w-full h-44 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1d3557]/70 to-transparent" />
            </div>

            {/* Question text */}
            <h2 className="text-white text-center mb-8 px-2 leading-snug">
              {question.text}
            </h2>

            {/* Options */}
            <div className="space-y-2.5">
              {question.options.map((option, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Button
                    onClick={() => onAnswer(option.value)}
                    className="w-full bg-white/10 hover:bg-white/20 active:bg-white/25 backdrop-blur-sm text-white border border-white/20 hover:border-white/40 py-6 rounded-2xl transition-all active:scale-[0.98] shadow-lg text-left justify-start px-5"
                    variant="ghost"
                  >
                    <span className="leading-relaxed text-sm">{option.text}</span>
                  </Button>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

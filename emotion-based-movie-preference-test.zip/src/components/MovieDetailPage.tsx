import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ChevronLeft, Play, ExternalLink, Bookmark, Pause } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState } from 'react';

interface MovieDetailPageProps {
  movie: {
    title: string;
    genre: string;
    image: string;
    year: string;
    description: string;
    mood: string[];
  };
  onBack: () => void;
}

interface MusicTrack {
  id: number;
  title: string;
  artist: string;
  album: string;
  cover: string;
  mood: string;
}

const musicTracks: MusicTrack[] = [
  {
    id: 1,
    title: 'Moonlit Dreams',
    artist: 'Luna Echo',
    album: 'Cinematic Moments',
    cover: 'https://images.unsplash.com/photo-1617173097223-5d9a368f7dbd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbGJ1bSUyMGNvdmVyJTIwYWVzdGhldGljfGVufDF8fHx8MTc2MzYxNDY4NXww&ixlib=rb-4.1.0&q=80&w=1080',
    mood: '잔잔함',
  },
  {
    id: 2,
    title: 'Nostalgic Waves',
    artist: 'The Emotions',
    album: 'Memory Lane',
    cover: 'https://images.unsplash.com/photo-1758597294781-48e6c13a5933?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXp6JTIwbXVzaWMlMjB2aW50YWdlfGVufDF8fHx8MTc2MzYxNDY4N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    mood: '감성적',
  },
  {
    id: 3,
    title: 'Soft Whispers',
    artist: 'Ambient Collective',
    album: 'Evening Soundscapes',
    cover: 'https://images.unsplash.com/photo-1626529547869-ded8fb07d056?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpZSUyMG11c2ljJTIwYWVzdGhldGljfGVufDF8fHx8MTc2MzYxNDY4Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    mood: '몽환적',
  },
  {
    id: 4,
    title: 'Golden Hour',
    artist: 'Cinema Sounds',
    album: 'Film Scores Vol.2',
    cover: 'https://images.unsplash.com/photo-1603569613911-606cb59f28e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMHBsYXlsaXN0JTIwbW9vZHxlbnwxfHx8fDE3NjM2MTQ2ODZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    mood: '따뜻함',
  },
  {
    id: 5,
    title: 'Ethereal Journey',
    artist: 'Dreamscape Orchestra',
    album: 'Soundtracks',
    cover: 'https://images.unsplash.com/photo-1741745978060-9add161ba2c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJvbmljJTIwbXVzaWMlMjBuZW9ufGVufDF8fHx8MTc2MzU3OTUzMnww&ixlib=rb-4.1.0&q=80&w=1080',
    mood: '감성적',
  },
  {
    id: 6,
    title: 'Quiet Moments',
    artist: 'Solo Piano',
    album: 'Reflections',
    cover: 'https://images.unsplash.com/photo-1757889693310-1e77c6063ba7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW55bCUyMHJlY29yZCUyMG11c2ljfGVufDF8fHx8MTc2MzUzNTY2MXww&ixlib=rb-4.1.0&q=80&w=1080',
    mood: '잔잔함',
  },
];

export default function MovieDetailPage({ movie, onBack }: MovieDetailPageProps) {
  const [playingTrack, setPlayingTrack] = useState<number | null>(null);
  const [isSaved, setIsSaved] = useState(false);

  const handlePlayTrack = (trackId: number) => {
    if (playingTrack === trackId) {
      setPlayingTrack(null);
    } else {
      setPlayingTrack(trackId);
    }
  };

  const handleSavePlaylist = () => {
    setIsSaved(!isSaved);
    // LocalStorage 저장 로직
    if (!isSaved) {
      localStorage.setItem(`playlist-${movie.title}`, JSON.stringify(movie));
    } else {
      localStorage.removeItem(`playlist-${movie.title}`);
    }
  };

  // 감정 데이터 (영화 분위기 기반)
  const emotions = [
    { label: '잔잔함', value: 85, color: 'bg-blue-400' },
    { label: '따뜻함', value: 75, color: 'bg-orange-400' },
    { label: '몽환적', value: 60, color: 'bg-purple-400' },
    { label: '감성적', value: 90, color: 'bg-pink-400' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1d3557] via-[#2d4a6f] to-[#1d3557]">
      {/* Header with Back Button */}
      <div className="sticky top-0 z-30 bg-[#1d3557]/95 backdrop-blur-md border-b border-white/10">
        <div className="max-w-md mx-auto px-5 pt-12 pb-4 flex items-center">
          <Button
            onClick={onBack}
            variant="ghost"
            className="text-white hover:bg-white/10 active:bg-white/20 -ml-2 active:scale-95 transition-all"
            size="sm"
          >
            <ChevronLeft className="size-5 mr-1" />
            뒤로
          </Button>
        </div>
      </div>

      <div className="max-w-md mx-auto px-5 py-6 pb-32">
        {/* Movie Summary Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-6"
        >
          <div className="flex gap-4 mb-5">
            {/* Movie Poster */}
            <div className="flex-shrink-0 w-28 rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src={movie.image}
                alt={movie.title}
                className="w-full aspect-[2/3] object-cover"
              />
            </div>

            {/* Movie Info */}
            <div className="flex-1">
              <h1 className="text-white mb-2 leading-tight">{movie.title}</h1>
              <div className="flex items-center gap-2 mb-3 text-white/60 text-sm">
                <span>{movie.year}</span>
                <span>·</span>
                <span>{movie.genre}</span>
              </div>

              {/* Mood Tags */}
              <div className="flex flex-wrap gap-2">
                {movie.mood.map((tag, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="bg-white/10 text-white/90 border-white/20 rounded-full px-3 py-1 text-xs"
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Description */}
          <p className="text-white/80 leading-relaxed text-sm">
            {movie.description}
          </p>
        </motion.div>

        {/* Emotion Analysis Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="bg-white/5 backdrop-blur-sm rounded-3xl p-5 mb-6 border border-white/10"
        >
          <h3 className="text-white mb-4">영화 감정 분석</h3>
          
          <div className="space-y-3 mb-4">
            {emotions.map((emotion, index) => (
              <div key={index}>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-white/70 text-sm">{emotion.label}</span>
                  <span className="text-white/90 text-sm">{emotion.value}%</span>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${emotion.value}%` }}
                    transition={{ duration: 1, delay: 0.2 + index * 0.1 }}
                    className={`h-full ${emotion.color} rounded-full`}
                  />
                </div>
              </div>
            ))}
          </div>

          <p className="text-white/60 text-sm leading-relaxed">
            이 영화는 <span className="text-white/90">감성적이고 잔잔한</span> 감정을 기반으로 플레이리스트가 생성됩니다.
          </p>
        </motion.div>

        {/* Music Playlist Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-6"
        >
          <h3 className="text-white mb-4">영화 분위기에 맞춘 플레이리스트</h3>
          
          <div className="space-y-3">
            {musicTracks.map((track, index) => (
              <motion.div
                key={track.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.05 }}
                className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10 hover:bg-white/10 active:bg-white/15 transition-all group"
              >
                <div className="flex items-center gap-3">
                  {/* Album Cover */}
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl overflow-hidden shadow-lg">
                    <ImageWithFallback
                      src={track.cover}
                      alt={track.album}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Track Info */}
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white text-sm mb-1 truncate leading-snug">{track.title}</h4>
                    <p className="text-white/60 text-xs truncate">{track.artist}</p>
                  </div>

                  {/* Mood Badge */}
                  <Badge
                    variant="secondary"
                    className="bg-white/10 text-white/80 border-white/20 text-xs px-2.5 py-0.5 rounded-full hidden xs:block"
                  >
                    {track.mood}
                  </Badge>

                  {/* Play Button */}
                  <Button
                    onClick={() => handlePlayTrack(track.id)}
                    variant="ghost"
                    size="sm"
                    className="flex-shrink-0 text-white hover:bg-white/20 active:bg-white/30 rounded-full size-11 p-0 transition-all active:scale-95"
                  >
                    {playingTrack === track.id ? (
                      <Pause className="size-4" fill="currentColor" />
                    ) : (
                      <Play className="size-4" fill="currentColor" />
                    )}
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Fixed Bottom CTA */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="fixed bottom-0 left-0 right-0 bg-gradient-to-t from-[#1d3557] via-[#1d3557]/98 to-transparent backdrop-blur-md border-t border-white/10 px-5 py-5 safe-area-bottom"
      >
        <div className="max-w-md mx-auto flex gap-3">
          <Button
            onClick={() => window.open('https://open.spotify.com', '_blank')}
            className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 active:from-purple-700 active:to-pink-700 text-white py-7 rounded-2xl shadow-lg active:scale-95 transition-all"
          >
            <ExternalLink className="size-5 mr-2" />
            <span className="text-sm">전체 플레이리스트 듣기</span>
          </Button>
          <Button
            onClick={handleSavePlaylist}
            variant="outline"
            className={`${
              isSaved 
                ? 'bg-white/20 border-white/40' 
                : 'bg-white/10 border-white/20'
            } hover:bg-white/20 active:bg-white/25 text-white hover:border-white/40 py-7 px-6 rounded-2xl transition-all active:scale-95`}
          >
            <Bookmark 
              className="size-5" 
              fill={isSaved ? 'currentColor' : 'none'}
            />
          </Button>
        </div>
      </motion.div>
    </div>
  );
}

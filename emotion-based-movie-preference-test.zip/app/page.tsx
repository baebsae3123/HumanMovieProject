"use client"

import App from "../src/App"

export default function Page() {
  return <App />
}

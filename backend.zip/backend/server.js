
import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import path from "path";

dotenv.config();
const app = express();
app.use(express.json());

// ★ 정적 파일 제공 설정
app.use(express.static(path.join(process.cwd(), "HumanMovieProject-main")));


dotenv.config();

app.use(express.json());

// MongoDB 연결 URI 만들기
const uri = `mongodb+srv://${process.env.MONGO_USER}:${process.env.MONGO_PASS}` +
            `@${process.env.MONGO_HOST}/${process.env.MONGO_DB}?retryWrites=true&w=majority`;

// DB 연결
mongoose.connect(uri)
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.error("MongoDB connection error:", err));

// 예시 Schema
const movieSchema = new mongoose.Schema({
  title: String,
  year: Number,
});

const Movie = mongoose.model("Movie", movieSchema);

// 라우트 예시
app.get("/", (req, res) => {
  res.send("Movie API Server Running");
});

// 영화 추가
app.post("/movie", async (req, res) => {
  try {
    const movie = new Movie(req.body);
    await movie.save();
    res.json({ success: true, movie });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 영화 목록
app.get("/movie", async (req, res) => {
  const movies = await Movie.find();
  res.json(movies);
});

// 서버 실행
app.listen(process.env.PORT, () =>
  console.log(`Server running on port ${process.env.PORT}`)
);

